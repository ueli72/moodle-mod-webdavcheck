<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * WebDAV Check upgrade script.
 *
 * @package    mod_webdavcheck
 * @copyright  2026 Ueli Leutwyler
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Upgrade function.
 *
 * @param int $oldversion Old plugin version
 * @return bool
 */
function xmldb_webdavcheck_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026042018) {
        // Add successtextformat and failuretextformat fields.
        $table = new xmldb_table('webdavcheck');

        $field = new xmldb_field('successtextformat', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '1', 'successtext');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('failuretextformat', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '1', 'failuretext');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2026042018, 'webdavcheck');
    }

    if ($oldversion < 2026042030) {
        // Add completionwebdav field for custom completion rule.
        $table = new xmldb_table('webdavcheck');

        $field = new xmldb_field('completionwebdav', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'failuretextformat');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2026042030, 'webdavcheck');
    }

    if ($oldversion < 2026102300) {
        // Encrypt the WebDAV password (stored as plain text by previous versions).
        $stored = get_config('mod_webdavcheck', 'webdavpass');
        if (!empty($stored)) {
            try {
                \core\encryption::decrypt($stored);
            } catch (\moodle_exception $e) {
                // The value is not decryptable, so it was stored as plain text.
                set_config('webdavpass', \core\encryption::encrypt($stored), 'mod_webdavcheck');
            }
        }

        upgrade_mod_savepoint(true, 2026102300, 'webdavcheck');
    }

    return true;
}
